import 'package:flutter/material.dart';


class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _weightController = TextEditingController();
  final _heightFeetController = TextEditingController();
  final _heightInchesController = TextEditingController();
  final _ageController = TextEditingController();
  String _gender = "Male";
  String _bmiResult = "";
  String _status = "";

  void _calculateBMI() {
    final double? weight = double.tryParse(_weightController.text);
    final int? heightFeet = int.tryParse(_heightFeetController.text);
    final int? heightInches = int.tryParse(_heightInchesController.text);
    final int? age = int.tryParse(_ageController.text);

    if (weight == null || heightFeet == null || heightInches == null || age == null || weight <= 0 || heightFeet < 0 || heightInches < 0) {
      setState(() {
        _bmiResult = "Invalid input";
        _status = "";
      });
      return;
    }

    final double heightInMeters = ((heightFeet * 12) + heightInches) * 0.0254;
    final double bmi = weight / (heightInMeters * heightInMeters);

    setState(() {
      _bmiResult = bmi.toStringAsFixed(1);
      if (bmi < 18.5) {
        _status = "Underweight";
      } else if (bmi >= 18.5 && bmi <= 24.9) {
        _status = "Normal";
      } else if (bmi >= 25.0 && bmi <= 39.9) {
        _status = "Overweight";
      } else {
        _status = "Obese";
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:const Text('BMI Calculator'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.teal.shade50,
                borderRadius: BorderRadius.circular(15),
              ),
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    'Enter Your Details',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.teal),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _ageController,
                    keyboardType: TextInputType.number,
                    decoration:const InputDecoration(
                      labelText: 'Age',
                      border: OutlineInputBorder(),
                      fillColor: Colors.white,
                      filled: true,
                      prefixIcon: Icon(Icons.calendar_today),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: RadioListTile<String>(
                          title:const Text("Male"),
                          value: "Male",
                          groupValue: _gender,
                          onChanged: (value) {
                            setState(() {
                              _gender = value!;
                            });
                          },
                        ),
                      ),
                      Expanded(
                        child: RadioListTile<String>(
                          title:const Text("Female"),
                          value: "Female",
                          groupValue: _gender,
                          onChanged: (value) {
                            setState(() {
                              _gender = value!;
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _weightController,
                    keyboardType: TextInputType.number,
                    decoration:const InputDecoration(
                      labelText: 'Weight (kg)',
                      border: OutlineInputBorder(),
                      fillColor: Colors.white,
                      filled: true,
                      prefixIcon: Icon(Icons.monitor_weight),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _heightFeetController,
                          keyboardType: TextInputType.number,
                          decoration:const InputDecoration(
                            labelText: 'Height (ft)',
                            border: OutlineInputBorder(),
                            fillColor: Colors.white,
                            filled: true,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: TextField(
                          controller: _heightInchesController,
                          keyboardType: TextInputType.number,
                          decoration:const InputDecoration(
                            labelText: 'Height (in)',
                            border: OutlineInputBorder(),
                            fillColor: Colors.white,
                            filled: true,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _calculateBMI,
                    child: Text('Calculate', style: TextStyle(fontSize: 18)),
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      padding: EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (_bmiResult.isNotEmpty)
                    Card(
                      color: Colors.teal.shade100,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          children: [
                            Text(
                              'BMI: $_bmiResult',
                              style:const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.teal),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Status: $_status',
                              style:const TextStyle(fontSize: 20, color: Colors.black87),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
